# Yash & Pradnya — Wedding Website

A responsive, static wedding invitation website built with vanilla HTML, CSS and JavaScript.

## Files

- `index.html` — page structure and content
- `style.css` — responsive visual design, animation and layout
- `script.js` — envelope opening, countdown, scratch-to-reveal card, event dialogs, gallery lightbox and copy-hashtag interaction
- `assets/` — optimised WebP artwork rendered from the printed invitation, plus a crop of the Y&P monogram from its Save the Date page

## Run locally

Keep the folder structure intact. Open `index.html` in a browser, or serve the folder with any static web server. No build step, database, backend or paid API is required.

## Publish

Upload the entire `py_wedding_ready` folder (not just the three source files) to any static host such as Netlify, GitHub Pages, Cloudflare Pages or a conventional web host. The relative asset paths are already configured.

## Content transcribed from the supplied six-page printed invitation

- **Couple:** Yash & Pradnya
- **Date:** Tuesday, 24 November 2026
- **Blessings:** Shree Balaji Maharaj
- **Hosts:** Smt. Sarita & Sh. Rajender Kumar Golchha
- **Yash:** Grandson of Late Smt. Jhamkoo Devi Golchha & Late Sh. Balchand Golchha
- **Pradnya:** Daughter of Smt. Vaishali Jain & Sh. Uttam Chandrakant Jain; granddaughter of Smt. Surekha Jain & Late Sh. Chandrakant Payanappa Jain

### Programme

| Date & time | Event | Venue |
|---|---|---|
| Sun 22 Nov · 10:00 AM | Shree Ganesh Poojan & Baan | T2-1408, RPS Auria, Sector-88, Faridabad |
| Mon 23 Nov · 11:00 AM | Haldi ke Rang | The Dream Venue, Sector-89, Faridabad |
| Mon 23 Nov · 12:30 PM | Lunch | The Dream Venue, Sector-89, Faridabad |
| Mon 23 Nov · 1:30 PM | Mehendi | The Dream Venue, Sector-89, Faridabad |
| Mon 23 Nov · 6:00 PM | Sangeet Night | The Dream Venue, Sector-89, Faridabad |
| Tue 24 Nov · 3:00 PM | Beend Banna & Sehra Bandi | The Dream Venue, Sector-89, Faridabad |
| Tue 24 Nov · 6:00 PM | Departure of Baraat | The Dream Venue, Sector-89, Faridabad |
| Tue 24 Nov · 7:00 PM | Wedding Gala Dinner | The Swaraj Convention by S.K., Sector-89, Faridabad |
| Tue 24 Nov · 11:45 PM | Pheras Begin | The Swaraj Convention by S.K., Sector-89, Faridabad |

### Special invitations (as printed)

- Pooja & Pritish Bhansali — Didi–Jijaji
- Aastha & Rohtash Golchha — Bhabhi–Bhaiya
- Gatik & Labhdhish — Nephews
- Shriyan — Nephew (shown under “Most Special Invitations”)

## Countdown and directions

The countdown targets **6:00 PM IST on 24 November 2026**, the printed Baraat departure time. Directions buttons open Google Maps searches for the venue names and addresses transcribed from the invitation. These are map searches, not verified venue pins.

## Before public launch

The supplied invitation does not specify dress codes, RSVP phone numbers, email addresses, or a formal RSVP link. The site therefore does not invent them. If you want RSVP functionality, add the confirmed contact details or connect a form service before publishing. The printed card also does not specify dress codes, so the event detail dialogs say this explicitly.

The separately supplied black-logo PDF was not available as a mounted local file during asset processing; the website uses a high-resolution crop of the matching Y&P logo artwork printed on page 1 of the invitation.

## Validation

The JavaScript passes `node --check`, the HTML parses successfully, and all local image references were checked. A full live-browser and cross-device acceptance test has not been performed.
