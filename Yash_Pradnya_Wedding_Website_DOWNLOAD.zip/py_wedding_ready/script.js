/* Yash & Pradnya — wedding website interactions.
   All event timings and venues below are transcribed from the six-page printed invitation.
   Add confirmed Google Maps links to `map` if you prefer direct pins over map searches. */
const WEDDING_CONFIG = {
  date: "2026-11-24T18:00:00+05:30",
  hashtag: "#YashWedsPradnya",
  events: {
    haldi: {
      title: "Haldi ke Rang",
      date: "Monday, 23 November 2026",
      time: "11:00 AM · Lunch at 12:30 PM",
      venue: "The Dream Venue, Sector-89, Faridabad",
      dress: "Not specified on the printed invitation",
      description: "A joyful morning of Haldi ke Rang, followed by lunch with family and friends.",
      map: "https://www.google.com/maps/search/?api=1&query=The+Dream+Venue+Sector+89+Faridabad"
    },
    mehendi: {
      title: "Mehendi",
      date: "Monday, 23 November 2026",
      time: "1:30 PM",
      venue: "The Dream Venue, Sector-89, Faridabad",
      dress: "Not specified on the printed invitation",
      description: "An afternoon of mehendi and togetherness as the wedding celebrations continue.",
      map: "https://www.google.com/maps/search/?api=1&query=The+Dream+Venue+Sector+89+Faridabad"
    },
    sangeet: {
      title: "Sangeet Night",
      date: "Monday, 23 November 2026",
      time: "6:00 PM",
      venue: "The Dream Venue, Sector-89, Faridabad",
      dress: "Not specified on the printed invitation",
      description: "An evening to celebrate with music, dance and the people we love.",
      map: "https://www.google.com/maps/search/?api=1&query=The+Dream+Venue+Sector+89+Faridabad"
    },
    wedding: {
      title: "Wedding Ceremony",
      date: "Tuesday, 24 November 2026",
      time: "3:00 PM · Beend Banna & Sehra Bandi | 6:00 PM · Departure of Baraat | 7:00 PM · Wedding Gala Dinner | 11:45 PM · Pheras Begin",
      venue: "The Swaraj Convention by S.K., Sector-89, Faridabad. Sehra Bandi and Baraat Departure: The Dream Venue, Sector-89, Faridabad.",
      dress: "Not specified on the printed invitation",
      description: "Join us for the wedding ceremony of Yash and Pradnya. Sehra Bandi and Baraat departure take place at The Dream Venue; the wedding gala dinner and pheras are at The Swaraj Convention by S.K.",
      map: "https://www.google.com/maps/search/?api=1&query=The+Swaraj+Convention+by+S.K.+Sector+89+Faridabad"
    }
  }
};

// Opening envelope
const introScreen = document.getElementById("introScreen");
const envelopeScene = document.getElementById("envelopeScene");
const openInvitation = document.getElementById("openInvitation");
let invitationOpened = false;
openInvitation?.addEventListener("click", () => {
  if (invitationOpened) return;
  invitationOpened = true;
  envelopeScene.classList.add("opened");
  window.setTimeout(() => {
    introScreen.classList.add("is-opening");
    document.body.classList.add("invitation-opened");
    document.getElementById("siteHeader")?.classList.add("visible");
  }, 1150);
  window.setTimeout(() => introScreen.remove(), 2300);
});

// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle?.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
mainNav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
  if (menuToggle) menuToggle.textContent = "☰";
}));

// Scroll reveal
const revealElements = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealElements.forEach(el => revealObserver.observe(el));
} else {
  revealElements.forEach(el => el.classList.add("visible"));
}

// Countdown targets the 6:00 PM Baraat departure on 24 November 2026 (IST).
function updateCountdown() {
  const target = new Date(WEDDING_CONFIG.date).getTime();
  const remaining = target - Date.now();
  const days = document.getElementById("countdownDays");
  if (!days) return;
  if (remaining <= 0) {
    days.textContent = "♥";
    document.querySelector(".days-label").textContent = "THE DAY IS HERE";
    ["countdownHours","countdownMinutes","countdownSeconds"].forEach(id => {
      const el = document.getElementById(id); if (el) el.textContent = "00";
    });
    document.querySelector(".scratch-reveal-kicker").textContent = "TODAY WE CELEBRATE";
    return;
  }
  days.textContent = Math.floor(remaining / 86400000).toString();
  document.getElementById("countdownHours").textContent = String(Math.floor((remaining % 86400000) / 3600000)).padStart(2,"0");
  document.getElementById("countdownMinutes").textContent = String(Math.floor((remaining % 3600000) / 60000)).padStart(2,"0");
  document.getElementById("countdownSeconds").textContent = String(Math.floor((remaining % 60000) / 1000)).padStart(2,"0");
}
updateCountdown();
window.setInterval(updateCountdown, 1000);

// Scratch-to-reveal interaction, supporting mouse, pen and touch.
const scratchCanvas = document.getElementById("scratchCanvas");
const scratchCard = document.getElementById("scratchCard");
let isScratching = false, scratchComplete = false, scratchCheckQueued = false;
if (scratchCanvas && scratchCard) {
  const ctx = scratchCanvas.getContext("2d", { willReadFrequently: true });
  function paintScratchSurface() {
    const rect = scratchCanvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    scratchCanvas.width = Math.round(rect.width * dpr);
    scratchCanvas.height = Math.round(rect.height * dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const w = rect.width, h = rect.height;
    const grad = ctx.createLinearGradient(0,0,w,h);
    grad.addColorStop(0,"#c7b38b"); grad.addColorStop(.5,"#e0d1b1"); grad.addColorStop(1,"#bda477");
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = grad; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = "rgba(255,248,228,.55)"; ctx.lineWidth = 1;
    for(let y=13;y<h;y+=19){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
    ctx.fillStyle = "#6f5b3e"; ctx.textAlign = "center";
    ctx.font = "12px DM Sans, sans-serif"; ctx.fillText("✦  A LITTLE SURPRISE  ✦",w/2,h/2-8);
    ctx.font = "10px DM Sans, sans-serif"; ctx.fillText("SCRATCH TO REVEAL",w/2,h/2+14);
  }
  function scratchAt(event) {
    if (scratchComplete) return;
    const rect = scratchCanvas.getBoundingClientRect();
    const x = event.clientX - rect.left, y = event.clientY - rect.top;
    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath(); ctx.arc(x,y,22,0,Math.PI*2); ctx.fill();
    if (!scratchCheckQueued) {
      scratchCheckQueued = true;
      requestAnimationFrame(checkScratchProgress);
    }
  }
  function checkScratchProgress() {
    scratchCheckQueued = false;
    if (scratchComplete) return;
    const data = ctx.getImageData(0,0,scratchCanvas.width,scratchCanvas.height).data;
    let transparent = 0, samples = 0;
    for(let i=3;i<data.length;i+=16){samples++;if(data[i]<80)transparent++;}
    if (transparent / samples > .52) completeScratch();
  }
  function completeScratch() {
    if (scratchComplete) return;
    scratchComplete = true;
    scratchCard.classList.add("scratched");
    scratchCanvas.style.pointerEvents = "none";
    launchConfetti();
  }
  scratchCanvas.addEventListener("pointerdown", event => {
    if (scratchComplete) return;
    isScratching = true;
    scratchCanvas.setPointerCapture?.(event.pointerId);
    scratchAt(event);
  });
  scratchCanvas.addEventListener("pointermove", event => { if(isScratching) scratchAt(event); });
  ["pointerup","pointercancel","lostpointercapture"].forEach(type => scratchCanvas.addEventListener(type,()=>{isScratching=false;}));
  paintScratchSurface();
  window.addEventListener("resize", () => { if(!scratchComplete) paintScratchSurface(); });
}

// Confetti burst without an external library.
function launchConfetti() {
  const layer = document.getElementById("confettiLayer");
  if (!layer || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colours = ["#9c3f42","#c5a66e","#7d8d70","#e2b7a9","#f3e7cf"];
  for(let i=0;i<105;i++){
    const piece=document.createElement("i");
    piece.className="confetti-piece";
    piece.style.left=(Math.random()*100)+"%";
    piece.style.background=colours[i%colours.length];
    piece.style.setProperty("--fall",(2.3+Math.random()*2.1)+"s");
    piece.style.setProperty("--delay",(Math.random()*.65)+"s");
    piece.style.setProperty("--drift",((Math.random()-.5)*220)+"px");
    layer.appendChild(piece);
    window.setTimeout(()=>piece.remove(),5200);
  }
}

// Event detail dialogs and live map searches.
const modal = document.getElementById("eventModal");
const modalMap = document.getElementById("modalMap");
let lastFocusedElement = null;
function openEventModal(key) {
  const event = WEDDING_CONFIG.events[key];
  if (!event) return;
  lastFocusedElement = document.activeElement;
  document.getElementById("modalKicker").textContent = "THE CELEBRATION";
  document.getElementById("modalTitle").textContent = event.title;
  document.getElementById("modalDate").textContent = event.date;
  document.getElementById("modalDescription").textContent = event.description;
  document.getElementById("modalTime").textContent = event.time;
  document.getElementById("modalVenue").textContent = event.venue;
  document.getElementById("modalDress").textContent = event.dress;
  modalMap.href = event.map || "#";
  modalMap.classList.toggle("disabled", !event.map);
  modalMap.setAttribute("aria-disabled", String(!event.map));
  modal.classList.add("open");
  modal.setAttribute("aria-hidden","false");
  document.body.classList.add("modal-open");
  modal.querySelector(".modal-close").focus();
}
function closeEventModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden","true");
  document.body.classList.remove("modal-open");
  lastFocusedElement?.focus();
}
document.querySelectorAll(".details-button").forEach(btn => btn.addEventListener("click",()=>openEventModal(btn.dataset.event)));
document.querySelectorAll(".directions-button").forEach(btn => btn.addEventListener("click",()=>{
  const event=WEDDING_CONFIG.events[btn.dataset.event];
  if(event?.map) window.open(event.map,"_blank","noopener");
  else openEventModal(btn.dataset.event);
}));
modal?.querySelector(".modal-close").addEventListener("click",closeEventModal);
modal?.addEventListener("click",e=>{if(e.target===modal)closeEventModal();});
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"){if(modal?.classList.contains("open"))closeEventModal();closeLightbox();}
});

// Printed invitation gallery.
const lightbox=document.getElementById("lightbox");
const lightboxImage=document.getElementById("lightboxImage");
function openLightbox(src,caption){
  lightboxImage.src=src;
  lightboxImage.alt=caption;
  document.getElementById("lightboxCaption").textContent=caption;
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden","false");
}
function closeLightbox(){
  if(!lightbox?.classList.contains("open"))return;
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden","true");
  lightboxImage.src="";
}
document.getElementById("viewSuite")?.addEventListener("click",()=>openLightbox("assets/invitation-page-1.webp","Save the date"));
document.querySelectorAll(".print-card").forEach(btn=>btn.addEventListener("click",()=>openLightbox(btn.dataset.image,btn.dataset.caption)));
lightbox?.querySelector(".lightbox-close").addEventListener("click",closeLightbox);
lightbox?.addEventListener("click",e=>{if(e.target===lightbox)closeLightbox();});

// Copy suggested wedding hashtag.
document.getElementById("copyHashtag")?.addEventListener("click",async()=>{
  const button=document.getElementById("copyHashtag");
  try {
    await navigator.clipboard.writeText(WEDDING_CONFIG.hashtag);
    button.textContent="COPIED!";
  } catch {
    button.textContent=WEDDING_CONFIG.hashtag;
  }
  window.setTimeout(()=>button.textContent="COPY WEDDING HASHTAG",1800);
});
